﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjRetanguloSRP.modelo
{
    class RetanguloMatematico
    {
        public double l1 { get; set; }
        public double l2 { get; set; }
        public double l3 { get; set; }
        public double l4 { get; set; }

        public RetanguloMatematico(Double l1, Double l2, Double l3, Double l4)
        {
            this.l1=l1;
            this.l2=l2;
            this.l3=l3;
            this.l4=l4;
        }
        public double Area()
        {
            return l1 * l2;
        }
        public double perimetro()
        {
            return l1 + l2 + l3 + l4;
        }
    }
}
