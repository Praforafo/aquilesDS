﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjRetanguloSRP.controle
{
    class RetanguloGrafico
    {
        public modelo.RetanguloMatematico Ret { get; set; }

        public RetanguloGrafico(modelo.RetanguloMatematico Ret)
        {
            this.Ret = Ret;
        }
    }
}
