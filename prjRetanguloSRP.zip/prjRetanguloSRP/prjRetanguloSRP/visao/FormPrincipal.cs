﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjRetanguloSRP.visao
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void txtL4_TextChanged(object sender, EventArgs e)
        {

        }

        private void lado1_Click(object sender, EventArgs e)
        {

        }

        modelo.RetanguloMatematico ret;

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            ret = new modelo.RetanguloMatematico(
                Double.Parse(txtL1.Text),
                 Double.Parse(txtL2.Text),
                  Double.Parse(txtL3.Text),
                   Double.Parse(txtL4.Text)
                );
            lbArea.Text = "Area:" + ret.Area();
            lbPerimetro.Text = "Perímetro:" + ret.perimetro();
        }
    }
}
