﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using prjControleRestaurante.modelo;

namespace prjControleRestaurante.controle
{
    class Tipo
    {
        string con = Conexao.Open("localhost", "restaurantedb", "root", "minas");
        public Object Listar()
        {   
            using (var banco = new restaurantedbEntidades())
            {
                //LINQ - linguagem de consulta
                banco.Database.Connection.ConnectionString = con;
                var consulta = from linhas in banco.tipo //LOAD LAZZING
                               select linhas;
                return consulta.ToList();
            }
        }

        public void Inserir(tipo registro)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                banco.tipo.Add(registro);
                banco.SaveChanges();
            }
        }

        public void Excluir(tipo registro)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                tipo reg = banco.tipo.FirstOrDefault(i => i.idtipo == registro.idtipo);
                banco.tipo.Remove(reg);
                banco.SaveChanges();
            }
        }

        public void Editar(tipo registro)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                tipo old = banco.tipo.FirstOrDefault(i => i.idtipo == registro.idtipo);
                banco.Entry(old).CurrentValues.SetValues(registro);
                banco.SaveChanges();
            }
        }

        public tipo Pesquisar(int idtipo)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                tipo tipo = banco.tipo.FirstOrDefault(i => i.idtipo == idtipo);
                return tipo;
            }
        }

        internal int proximoCodigo()
        {
            using (var banco = new restaurantedbEntidades())
            {​
                banco.Database.Connection.ConnectionString = con;
                int cod = 0;
                try
                {​
                    cod = banco.tipo.Max(i => i.idtipo);
                    return cod + 1;
                }​
                catch (Exception)
                {​
                    cod = 1;
                }​

                return cod;
            }​
        }
    }
}
