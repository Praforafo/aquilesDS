﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FuncoesMatematica;

namespace prjTesteTLL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool teste;
            int num = Int16.Parse(txtnum.Text);
            teste = NmrNatural.IsPar(num);
            lbResultado.Text = teste ? "Número Par" : "Número Impar";
        }

        private void btnPerfeito_Click(object sender, EventArgs e)
        {
            bool teste;
            int num = Int16.Parse(txtnum.Text);
            teste = NmrNatural.perfeito(num);
            lbResultado.Text = teste ? "Número Perfeito" : "Número Não Perfeito";
        }

        private void btnPrimo_Click(object sender, EventArgs e)
        {
            bool teste;
            int num = Int16.Parse(txtnum.Text);
            teste = NmrNatural.primo(num);
            lbResultado.Text = teste ? "Número Primo" : "Número Não Primo";
        }
    }
}
