﻿namespace prjTesteTLL
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">verdade se for necessário descartar os recursos gerenciados; caso contrário, falso.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte do Designer - não modifique
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtnum = new System.Windows.Forms.TextBox();
            this.btnPar = new System.Windows.Forms.Button();
            this.btnPrimo = new System.Windows.Forms.Button();
            this.btnPerfeito = new System.Windows.Forms.Button();
            this.lbResultado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Digite um Número:";
            // 
            // txtnum
            // 
            this.txtnum.Location = new System.Drawing.Point(112, 9);
            this.txtnum.Name = "txtnum";
            this.txtnum.Size = new System.Drawing.Size(171, 20);
            this.txtnum.TabIndex = 1;
            // 
            // btnPar
            // 
            this.btnPar.Location = new System.Drawing.Point(12, 38);
            this.btnPar.Name = "btnPar";
            this.btnPar.Size = new System.Drawing.Size(75, 23);
            this.btnPar.TabIndex = 2;
            this.btnPar.Text = "PAR";
            this.btnPar.UseVisualStyleBackColor = true;
            this.btnPar.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnPrimo
            // 
            this.btnPrimo.Location = new System.Drawing.Point(208, 38);
            this.btnPrimo.Name = "btnPrimo";
            this.btnPrimo.Size = new System.Drawing.Size(75, 23);
            this.btnPrimo.TabIndex = 2;
            this.btnPrimo.Text = "PRIMO";
            this.btnPrimo.UseVisualStyleBackColor = true;
            this.btnPrimo.Click += new System.EventHandler(this.btnPrimo_Click);
            // 
            // btnPerfeito
            // 
            this.btnPerfeito.Location = new System.Drawing.Point(112, 38);
            this.btnPerfeito.Name = "btnPerfeito";
            this.btnPerfeito.Size = new System.Drawing.Size(75, 23);
            this.btnPerfeito.TabIndex = 2;
            this.btnPerfeito.Text = "PERFEITO";
            this.btnPerfeito.UseVisualStyleBackColor = true;
            this.btnPerfeito.Click += new System.EventHandler(this.btnPerfeito_Click);
            // 
            // lbResultado
            // 
            this.lbResultado.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lbResultado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbResultado.Location = new System.Drawing.Point(15, 75);
            this.lbResultado.Name = "lbResultado";
            this.lbResultado.Size = new System.Drawing.Size(268, 162);
            this.lbResultado.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(299, 255);
            this.Controls.Add(this.lbResultado);
            this.Controls.Add(this.btnPerfeito);
            this.Controls.Add(this.btnPrimo);
            this.Controls.Add(this.btnPar);
            this.Controls.Add(this.txtnum);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Teste de DLL";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtnum;
        private System.Windows.Forms.Button btnPar;
        private System.Windows.Forms.Button btnPrimo;
        private System.Windows.Forms.Button btnPerfeito;
        private System.Windows.Forms.Label lbResultado;
    }
}

