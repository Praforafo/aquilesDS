﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProdutoAPI
{
    public class ProdutoRepositorio:IprodutoRepositorio
    {

        public Produto p { get; set; }

        public ProdutoRepositorio(Produto p)
        {
            this.p = p;
        }

        public void ler()
        {
            p.Imorimir();
        }
    }
}
