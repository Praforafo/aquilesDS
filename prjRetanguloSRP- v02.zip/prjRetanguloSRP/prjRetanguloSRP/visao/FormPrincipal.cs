﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjRetanguloSRP.visao
{
    public partial class FormPrincipal : Form
    {
        public FormPrincipal()
        {
            InitializeComponent();
        }

        private void txtL4_TextChanged(object sender, EventArgs e)
        {

        }

        private void lado1_Click(object sender, EventArgs e)
        {

        }

        modelo.RetanguloMatematico ret;
        controle.RetanguloGrafico rg;

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            ret = new modelo.RetanguloMatematico(
                Double.Parse(txtL1.Text),
                 Double.Parse(txtL2.Text)
                );
            lbArea.Text = "Area:" + ret.Area();
            lbPerimetro.Text = "Perímetro:" + ret.perimetro();
        }

        private void btnPlotar_Click(object sender, EventArgs e)
        {
                btnCalcular_Click(null, null);
                rg = new controle.RetanguloGrafico(ret);
                rg.desenhar(0, 0, pnGrafico.CreateGraphics());
        }

        private void pnGrafico_MouseClick(object sender, MouseEventArgs e)
        {
            if (rg != null)
            {
                rg = new controle.RetanguloGrafico(ret);
                rg.desenhar(e.X, e.Y,pnGrafico.CreateGraphics());
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            pnGrafico.CreateGraphics().Clear(Color.White);
        }
    }
}
