﻿namespace prjRetanguloSRP.visao
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtL2 = new System.Windows.Forms.TextBox();
            this.txtL1 = new System.Windows.Forms.TextBox();
            this.lado3 = new System.Windows.Forms.Label();
            this.lado1 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.lbArea = new System.Windows.Forms.Label();
            this.lbPerimetro = new System.Windows.Forms.Label();
            this.pnGrafico = new System.Windows.Forms.Panel();
            this.btnPlotar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel1.Controls.Add(this.txtL2);
            this.panel1.Controls.Add(this.txtL1);
            this.panel1.Controls.Add(this.lado3);
            this.panel1.Controls.Add(this.lado1);
            this.panel1.Controls.Add(this.lbPerimetro);
            this.panel1.Controls.Add(this.lbArea);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(523, 100);
            this.panel1.TabIndex = 0;
            // 
            // txtL2
            // 
            this.txtL2.Location = new System.Drawing.Point(172, 38);
            this.txtL2.Name = "txtL2";
            this.txtL2.Size = new System.Drawing.Size(100, 24);
            this.txtL2.TabIndex = 2;
            this.txtL2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtL1
            // 
            this.txtL1.Location = new System.Drawing.Point(12, 38);
            this.txtL1.Name = "txtL1";
            this.txtL1.Size = new System.Drawing.Size(100, 24);
            this.txtL1.TabIndex = 2;
            this.txtL1.Tag = "";
            this.txtL1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lado3
            // 
            this.lado3.AutoSize = true;
            this.lado3.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lado3.Location = new System.Drawing.Point(200, 9);
            this.lado3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lado3.Name = "lado3";
            this.lado3.Size = new System.Drawing.Size(48, 16);
            this.lado3.TabIndex = 1;
            this.lado3.Text = "lado 2";
            // 
            // lado1
            // 
            this.lado1.AutoSize = true;
            this.lado1.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lado1.Location = new System.Drawing.Point(35, 10);
            this.lado1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lado1.Name = "lado1";
            this.lado1.Size = new System.Drawing.Size(52, 16);
            this.lado1.TabIndex = 1;
            this.lado1.Text = "Lado 1";
            this.lado1.Click += new System.EventHandler(this.lado1_Click);
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(12, 106);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(115, 55);
            this.btnCalcular.TabIndex = 1;
            this.btnCalcular.Text = "CALCULAR";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // lbArea
            // 
            this.lbArea.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lbArea.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbArea.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbArea.Location = new System.Drawing.Point(324, 10);
            this.lbArea.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbArea.Name = "lbArea";
            this.lbArea.Size = new System.Drawing.Size(187, 31);
            this.lbArea.TabIndex = 1;
            this.lbArea.Text = "Area: 0";
            this.lbArea.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbPerimetro
            // 
            this.lbPerimetro.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lbPerimetro.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbPerimetro.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPerimetro.Location = new System.Drawing.Point(324, 54);
            this.lbPerimetro.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbPerimetro.Name = "lbPerimetro";
            this.lbPerimetro.Size = new System.Drawing.Size(187, 31);
            this.lbPerimetro.TabIndex = 1;
            this.lbPerimetro.Text = "Perímetro: 0";
            this.lbPerimetro.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnGrafico
            // 
            this.pnGrafico.BackColor = System.Drawing.Color.White;
            this.pnGrafico.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pnGrafico.Location = new System.Drawing.Point(12, 167);
            this.pnGrafico.Name = "pnGrafico";
            this.pnGrafico.Size = new System.Drawing.Size(499, 297);
            this.pnGrafico.TabIndex = 2;
            this.pnGrafico.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pnGrafico_MouseClick);
            // 
            // btnPlotar
            // 
            this.btnPlotar.Location = new System.Drawing.Point(133, 106);
            this.btnPlotar.Name = "btnPlotar";
            this.btnPlotar.Size = new System.Drawing.Size(115, 55);
            this.btnPlotar.TabIndex = 1;
            this.btnPlotar.Text = "PLOTAR";
            this.btnPlotar.UseVisualStyleBackColor = true;
            this.btnPlotar.Click += new System.EventHandler(this.btnPlotar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(396, 106);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(115, 55);
            this.btnLimpar.TabIndex = 1;
            this.btnLimpar.Text = "LIMPAR";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(523, 476);
            this.Controls.Add(this.pnGrafico);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnPlotar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "FormPrincipal";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LUTADOR DE RETANGULO";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtL2;
        private System.Windows.Forms.TextBox txtL1;
        private System.Windows.Forms.Label lado3;
        private System.Windows.Forms.Label lado1;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Label lbArea;
        private System.Windows.Forms.Label lbPerimetro;
        private System.Windows.Forms.Panel pnGrafico;
        private System.Windows.Forms.Button btnPlotar;
        private System.Windows.Forms.Button btnLimpar;
    }
}