﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prjRetanguloSRP.controle
{
    class RetanguloGrafico
    {
        public modelo.RetanguloMatematico Ret { get; set; }

        public RetanguloGrafico(modelo.RetanguloMatematico Ret)
        {
            this.Ret = Ret;
        }

        public void desenhar(double x, double y, Graphics g)
        {
            Pen caneta = new Pen(Color.Red, 2);
            g.DrawRectangle(caneta, (int) x, (int) y, (int) Ret.l1, (int) Ret.l2);
        }
    }
}
