﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API_Lista;

namespace ConsoleTDDlista
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Clear();
            Console.WriteLine("TESTE API LISTA");
            List<double> amostra = new List<double>();
            for (int x = 1; x <= 10000; x++)
                amostra.Add(x);
            

            TimeSpan tempo = new TimeSpan();
            DateTime inicio = DateTime.Now;
            double resultado = ListaAPI.Somar(amostra);
            bool teste = resultado == 50005000;
            if (teste) Console.WriteLine("SOMAR SUCESS");
            else Console.WriteLine("SOMAR FAIL ;-;");
            Console.WriteLine("Obitido: {0} Esperado: {1}", resultado, 50005000);
            DateTime fim = DateTime.Now;
            tempo = fim - inicio;
            double ms = tempo.TotalMilliseconds;
            Console.WriteLine("Tempo: {0} ms \n", ms);


            tempo = new TimeSpan();
            inicio = DateTime.Now;
            resultado = ListaAPI.Media(amostra);
            teste = resultado == 5000.5;
            if (teste) Console.WriteLine("Média SUCESS");
            else Console.WriteLine("Média FAIL ;-;");
            Console.WriteLine("Obitido: {0} Esperado: {1}", resultado, 5000.5);
            fim = DateTime.Now;
            tempo = fim - inicio;
            ms = tempo.TotalMilliseconds;
            Console.WriteLine("Tempo: {0} ms", ms);

            Console.ReadKey();
          }
    }
}
