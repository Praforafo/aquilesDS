﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API_BANCO;
using System.Threading;

namespace TESTE_CONTA
{
    class Program
    {
        static List<IConta> Contas;

        static void Main(string[] args)
        {
            Contas = new List<IConta>();
            Contas.Add(new ContaPoupanca(1, "João", 400));
            Contas.Add(new ContaCorrente(2, "Maria", 300, 300));

            Console.WriteLine("Extrato Bancario");

            foreach (IConta conta in Contas)
            {
                Console.WriteLine("");
                conta.Depositar(400,"Transferencia Conta");
                Thread.Sleep(1000);
                Console.WriteLine("");
                conta.Sacar(900,"Pagamentos");
            }
            Console.ReadKey();
        }
    }
}
