﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_BANCO
{
    public abstract class Conta : IConta
    {
        public long Numero { get; set; }
        public string Nome { get; set; }
        public double Saldo { get; set; }

        public Conta(long Numero, string Nome, double Saldo)
        {
            this.Saldo = Saldo;
            this.Numero = Numero;
            this.Nome = Nome;
        }

        public abstract void Debitar(double valor);

        public void Creditar(double valor)
        {
            this.Saldo += valor;
            Console.Write("Valor : {0:C2}", valor);
            Console.WriteLine("\tValor : {0:C2}", Saldo);
        }



        public void Sacar(double valor, string Descricao)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Data da Operacao:{0}", DateTime.Now.ToLongDateString());
            Debitar(valor);
        }

        public void Depositar(double valor, string Descricao)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Numero da Conta:{0}", this.Numero);
            Console.WriteLine("Operacao:{0} ", Descricao);
            Console.WriteLine("Data da Operacao:{0}", DateTime.Now.ToLongDateString()); 
            Creditar(valor);
        }
    }
}