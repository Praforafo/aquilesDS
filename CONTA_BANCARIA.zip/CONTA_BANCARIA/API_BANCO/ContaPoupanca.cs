﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_BANCO
{
    public class ContaPoupanca : Conta
    {
        public ContaPoupanca(long Numero, string Nome, double Saldo):base(Numero,Nome,Saldo)
        {

        }
        public override void Debitar(double valor)
        {
            if ((Saldo - valor) < 0)
            {
                Console.WriteLine("Saldo Insuficiente");
            }
            else
            {
                this.Saldo += valor;
            }
            Console.Write("Valor DB: ({0:C2})", valor);
            Console.WriteLine("\tValor : {0:C2}", Saldo);
        }
    }
}
