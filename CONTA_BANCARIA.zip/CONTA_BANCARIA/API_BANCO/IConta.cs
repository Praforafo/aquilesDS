﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_BANCO
{
    public interface IConta
    {
        void Debitar(double valor);
        void Creditar(double valor);

        void Sacar(double valor, string Descricao);
        void Depositar(double valor, string Descricao);
    }
}
