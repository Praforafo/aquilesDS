﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_BANCO
{
    public class ContaCorrente : Conta
    {
        public double limite { get; set; }
        public ContaCorrente(long Numero, string Nome, double Saldo, double limite)
            :base(Numero,Nome,Saldo)
        {

        }

        public override void Debitar(double valor)
        {
            double disponivel = Saldo + limite;
            if (valor > disponivel)
            {
                Console.WriteLine("Saldo Insuficiente");
            }
            else
            {
                this.Saldo -= valor;
            }
            Console.Write("Valor DB: ({0:C2})", valor);
            Console.WriteLine("\tValor : {0:C2}", Saldo);
        }
    }
}
