﻿namespace Encriptador_Documento
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">verdade se for necessário descartar os recursos gerenciados; caso contrário, falso.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte do Designer - não modifique
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.LbCaminho = new System.Windows.Forms.Label();
            this.LbLocal = new System.Windows.Forms.Label();
            this.BtnCodificar = new System.Windows.Forms.Button();
            this.BtnSair = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.BtnAbrir = new System.Windows.Forms.Button();
            this.BtnDescodificar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LbCaminho
            // 
            this.LbCaminho.Location = new System.Drawing.Point(17, 9);
            this.LbCaminho.Name = "LbCaminho";
            this.LbCaminho.Size = new System.Drawing.Size(51, 15);
            this.LbCaminho.TabIndex = 1;
            this.LbCaminho.Text = "Caminho";
            // 
            // LbLocal
            // 
            this.LbLocal.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.LbLocal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LbLocal.Location = new System.Drawing.Point(17, 24);
            this.LbLocal.Name = "LbLocal";
            this.LbLocal.Size = new System.Drawing.Size(252, 28);
            this.LbLocal.TabIndex = 2;
            this.LbLocal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BtnCodificar
            // 
            this.BtnCodificar.Location = new System.Drawing.Point(20, 120);
            this.BtnCodificar.Name = "BtnCodificar";
            this.BtnCodificar.Size = new System.Drawing.Size(252, 39);
            this.BtnCodificar.TabIndex = 3;
            this.BtnCodificar.Text = "Codificar";
            this.BtnCodificar.UseVisualStyleBackColor = true;
            this.BtnCodificar.Click += new System.EventHandler(this.BtnCodificar_Click);
            // 
            // BtnSair
            // 
            this.BtnSair.BackColor = System.Drawing.Color.Red;
            this.BtnSair.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.BtnSair.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnSair.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.BtnSair.Location = new System.Drawing.Point(20, 210);
            this.BtnSair.Name = "BtnSair";
            this.BtnSair.Size = new System.Drawing.Size(252, 39);
            this.BtnSair.TabIndex = 4;
            this.BtnSair.Text = "SAIR";
            this.BtnSair.UseVisualStyleBackColor = false;
            this.BtnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // BtnAbrir
            // 
            this.BtnAbrir.Location = new System.Drawing.Point(17, 55);
            this.BtnAbrir.Name = "BtnAbrir";
            this.BtnAbrir.Size = new System.Drawing.Size(252, 39);
            this.BtnAbrir.TabIndex = 5;
            this.BtnAbrir.Text = "Abrir Documento";
            this.BtnAbrir.UseVisualStyleBackColor = true;
            this.BtnAbrir.Click += new System.EventHandler(this.BtnAbrir_Click);
            // 
            // BtnDescodificar
            // 
            this.BtnDescodificar.Location = new System.Drawing.Point(20, 165);
            this.BtnDescodificar.Name = "BtnDescodificar";
            this.BtnDescodificar.Size = new System.Drawing.Size(252, 39);
            this.BtnDescodificar.TabIndex = 6;
            this.BtnDescodificar.Text = "Decodificar";
            this.BtnDescodificar.UseVisualStyleBackColor = true;
            this.BtnDescodificar.Click += new System.EventHandler(this.BtnDescodificar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.BtnDescodificar);
            this.Controls.Add(this.BtnAbrir);
            this.Controls.Add(this.BtnSair);
            this.Controls.Add(this.BtnCodificar);
            this.Controls.Add(this.LbLocal);
            this.Controls.Add(this.LbCaminho);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Encriptar Documento";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label LbCaminho;
        private System.Windows.Forms.Label LbLocal;
        private System.Windows.Forms.Button BtnCodificar;
        private System.Windows.Forms.Button BtnSair;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button BtnAbrir;
        private System.Windows.Forms.Button BtnDescodificar;
    }
}

