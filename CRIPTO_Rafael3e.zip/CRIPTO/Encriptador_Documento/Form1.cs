﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CRIPTO_API;
using System.IO;

namespace Encriptador_Documento
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnAbrir_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            LbLocal.Text = openFileDialog1.FileName;
        }

        private void BtnCodificar_Click(object sender, EventArgs e)
        {
            StreamReader arquivo = new StreamReader(LbCaminho.Text);
            int qtd = File.ReadAllLines(LbCaminho.Text).Count();

            StreamWriter docsaida = new StreamWriter("E:\\saida.txt");
            for (int i = 0; i < qtd; i++)
            {
                string linha = arquivo.ReadLine();
                docsaida.WriteLine(Cripto.Codificar(linha));
            }
            arquivo.Close();
            docsaida.Close();
            MessageBox.Show("Documento codificado com sucesso");
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnDescodificar_Click(object sender, EventArgs e)
        {
            StreamReader arquivo = new StreamReader(LbCaminho.Text);
            int qtd = File.ReadAllLines(LbCaminho.Text).Count();

            StreamWriter docsaida = new StreamWriter("E:\\saida.txt");
            for (int i = 0; i < qtd; i++)
            {
                string linha = arquivo.ReadLine();
                docsaida.WriteLine(Cripto.Decodificar(linha));
            }
            arquivo.Close();
            docsaida.Close();
            MessageBox.Show("Documento decodificado com sucesso");
        }

        
    }
}
