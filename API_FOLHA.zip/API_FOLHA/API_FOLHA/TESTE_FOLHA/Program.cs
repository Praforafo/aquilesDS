﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API_FOLHA_SIP;

namespace TESTE_FOLHA
{
    class Program
    {
        static ILH Empresa;

        static void Main(string[] args)
        {
            Empresa = new RH();

            Empresa.Adicionar(new Funcionario(1, "Xixo", 0, 0));
            Empresa.Adicionar(new Funcionario(2, "Danilo", 0, 0));
            Empresa.Adicionar(new Estagiario(3, "Edgarzinho", 0, 0, 200));
            Empresa.Imprimir();
            Console.CursorTop = 0;
            Console.ReadKey();
        }
    }
}
