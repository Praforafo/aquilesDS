﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_FOLHA_SIP
{
    public interface IEstagiario : ISalario
    {
        void Imprimir();
        void Ponto(double Horas, double SH);
    }
}
