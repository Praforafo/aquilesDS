﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_FOLHA_SIP
{
    public class RH : ILH
    {
        public ArrayList Empregados { get; set; }
        public RH()
        {
            Empregados = new ArrayList();
        }

        public void Adicionar<T> (T emp)
        {
            Empregados.Add(emp);
        }
        
        public void Imprimir()
        {
            Random horas = new Random();
            foreach (dynamic emp in Empregados)
            {
                double h = 0;
                if (emp is Funcionario) horas.Next(180, 200);
                if (emp is Estagiario) horas.Next(80, 200);
                emp.Ponto(h, 18);
                emp.Imprimir();
                System.Threading.Thread.Sleep(10);
            }
        }
    }
}
