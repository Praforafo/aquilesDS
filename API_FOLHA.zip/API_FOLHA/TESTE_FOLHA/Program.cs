﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API_FOLHA_SIP;

namespace TESTE_FOLHA
{
    class Program
    {
        static List<IFuncionario> Empregados;
        static List<IEstagiario> Estagiario;

        static void Main(string[] args)
        {
            Empregados = new List<IFuncionario>();
            Estagiario = new List<IEstagiario>();
            Empregados.Add(new Funcionario(1, "Xixo", 0, 0));
            Empregados.Add(new Funcionario(2, "Danilo", 0, 0));
            Estagiario.Add(new Estagiario(3, "Edigarzinho", 0, 0, 200));
            Imprimir();
            Console.ReadKey();
        }

        private static void Imprimir()
        {
            Random horas = new Random();
            foreach (IFuncionario emp in Empregados)
            {
                double h = horas.Next(160, 200);
                emp.Ponto(h, 18);
                emp.Imprimir();
                System.Threading.Thread.Sleep(10);
            }
            foreach(IEstagiario aspira in Estagiario)
            {
                double h = horas.Next(160, 200);
                aspira.Ponto(h, 18);
                aspira.Imprimir();
                System.Threading.Thread.Sleep(10);
            }
        }
    }
}
