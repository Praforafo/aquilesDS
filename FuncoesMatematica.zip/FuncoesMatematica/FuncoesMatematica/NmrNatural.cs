﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FuncoesMatematica
{
    public class NmrNatural
    {
        public static bool IsPar (int n)
        {
            if (n % 2 == 0) return true;
            else return false;
        }

        public static bool primo(int n)
        {
            int cont = 0;
            for (int i = 1; i <= n; i++)
            {
                if (n %1 == 0) cont++;
            }
            if (cont == 2) return true;
            else return false;
        }

        public static bool perfeito(int n)
        {
            int soma = 0;
            for (int i = 1; i < n; i++)
            {
                if (n % 1 == 0) soma+=i;
            }
            if (soma == n) return true;
            else return false;
        }


    }
}
