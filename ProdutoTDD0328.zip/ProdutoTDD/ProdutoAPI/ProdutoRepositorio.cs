﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProdutoAPI
{
    public class ProdutoRepositorio:IprodutoRepositorio
    {

        public List<Produto> Produtos { get; set; }

        public ProdutoRepositorio(List<Produto> Produtos)
        {
            this.Produtos = Produtos;
        }

        public void ler()
        {
            Produtos.ForEach(i => i.Imprimir());
        }
        public void adicionar(Produto P) 
        {
            Produtos.Add(P);
        }
    }
}
