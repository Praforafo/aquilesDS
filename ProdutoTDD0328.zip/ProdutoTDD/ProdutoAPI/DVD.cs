﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProdutoAPI
{
    public class DVD:Produto
    {
        public string Ano { get; set; }
        public string Diretor { get; set; }
        public DVD (int ID, string Nome, string Fabricante, string Ano, string Diretor)
            :base(ID, Nome, Fabricante)
        {
            this.Ano = Ano;
            this.Diretor = Diretor;
        }

        public override void Imprimir()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Produto DVD");
            Console.WriteLine("ID: {0}", ID);
            Console.WriteLine("Titulo: {0}", Nome);
            Console.WriteLine("Estudio: {0}", Fabricante);
            Console.WriteLine("Ano: {0}", Ano);
            Console.WriteLine("Diretor: {0}", Diretor);
        }
    }
}
