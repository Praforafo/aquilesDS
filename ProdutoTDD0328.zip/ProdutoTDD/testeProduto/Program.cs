﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProdutoAPI;

namespace testeProduto
{
    class Program
    {
        static void Main(string[] args)
        {
            IprodutoRepositorio banco = 
                new ProdutoRepositorio(new List<Produto>());

             banco.adicionar (
                new Livro (1,"DOM CASMURRO","RECORD","MACHADO DE ASSIS","123456"
                         )
                );
            banco.adicionar (
                new DVD (2, "Senhor dos Aneis: O Retorno do Rei", "New Line Cinema", "Peter Jacskon", "2003")
                );
            banco.adicionar(
                new CD (3, "Hits do Verão", "DJ Marquinho", "Música Eletronica", 2017)
                );
            Console.BackgroundColor = ConsoleColor.Black;
            Console.Clear();
            banco.ler();
            Console.ReadKey();
        }
    }
}
