﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjControleRestaurante.visao
{
    public partial class FormProduto : Form
    {
        public FormProduto()
        {
            InitializeComponent();
        }
        List<modelo.produto> Produtos;

        private void FormProduto_FormClosing(object sender, FormClosingEventArgs e)
        {
            FormPrincipal pai = (FormPrincipal)this.MdiParent;
            pai.frProduto = null;
        }

        private void FormProduto_Load(object sender, EventArgs e)
        {
            controle.ProdutoDB tabela = new controle.ProdutoDB();
            Produtos = (List<modelo.produto>)tabela.Listar();
            bs.DataSource = Produtos;

            lbCodigo.DataBindings.Add(new Binding("Text",bs,"idproduto"));
            lbNome.DataBindings.Add(new Binding("Text", bs, "nome"));
            Binding bPreco = new Binding("Text", bs, "preco");
            bPreco.Format += bPreco_Format;
            lbPreco.DataBindings.Add(bPreco);
            lbTipo.DataBindings.Add(new Binding("Text", bs, "tipo.descricao"));
        }

        void bPreco_Format(object sender, ConvertEventArgs e)
        {
            try
            {
                double preco = Double.Parse(e.Value.ToString());
                e.Value = preco.ToString("C2");
            }
            catch (Exception)
            {
                e.Value = "R$00,00";
            }
        }

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            FormFichaProduto ficha = new FormFichaProduto();
            ficha.Registro = null;
            ficha.ShowDialog();
            
            if (ficha.Registro != null)
            {
                controle.ProdutoDB tabela = new controle.ProdutoDB();
                bs.Add(tabela.Pesquisar(ficha.Registro.idproduto));
                bs.ResetBindings(false);
                bs.MoveLast();
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            FormFichaProduto ficha = new FormFichaProduto();
            ficha.Registro = (modelo.produto)bs.Current;
            ficha.ShowDialog();

            if (ficha.Registro != null)
            {
                bs.ResetBindings(false);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            DialogResult op;
            modelo.produto p = (modelo.produto)bs.Current;
            op = MessageBox.Show("Deseja Excluir '" + p.nome + "' ?", "ALERTA", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (op == DialogResult.Yes)
            {
                controle.ProdutoDB tabela = new controle.ProdutoDB();
                tabela.Excluir(p);
            }
        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            FormPesquisarProduto pesquisa = new FormPesquisarProduto();
            pesquisa.ShowDialog();
            if (pesquisa.Codigo != 0)
            {
                modelo.produto p = Produtos.First(i => i.idproduto == pesquisa.Codigo);
                bs.Position = bs.IndexOf(p);
                btnEditar_Click(sender, e);
            }
        }
    }
}
