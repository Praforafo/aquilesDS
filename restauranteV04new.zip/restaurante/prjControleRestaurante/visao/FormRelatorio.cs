﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjControleRestaurante.visao
{
    public partial class FormRelatorio : Form
    {
        public FormRelatorio()
        {
            InitializeComponent();
        }

        internal string Caminho { get; set; }
        internal DataSet Ds { get; set; }

        private void FormRelatorio_Load(object sender, EventArgs e)
        {

            try
            {
                reportViewer1.LocalReport.DataSources.Clear();
                ReportDataSource source = null;
                source = new ReportDataSource(Ds.DataSetName, Ds.Tables[0]);
                reportViewer1.LocalReport.ReportPath = @Caminho;
                reportViewer1.LocalReport.DataSources.Add(source);
                reportViewer1.ProcessingMode = ProcessingMode.Local;
                reportViewer1.DocumentMapCollapsed = false;
                this.reportViewer1.RefreshReport();
            }
            catch (Exception erro)
            {
                MessageBox.Show("Erro ao abrir o relatório:" + erro.Message,
                      "Alerta", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
