﻿namespace prjControleRestaurante.visao
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPrincipal));
            this.menu = new System.Windows.Forms.MenuStrip();
            this.mnProduto = new System.Windows.Forms.ToolStripMenuItem();
            this.mnCardapios = new System.Windows.Forms.ToolStripMenuItem();
            this.mnMesas = new System.Windows.Forms.ToolStripMenuItem();
            this.mnSair = new System.Windows.Forms.ToolStripMenuItem();
            this.menu.SuspendLayout();
            this.SuspendLayout();
            // 
            // menu
            // 
            this.menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnProduto,
            this.mnCardapios,
            this.mnMesas,
            this.mnSair});
            this.menu.Location = new System.Drawing.Point(0, 0);
            this.menu.Name = "menu";
            this.menu.Size = new System.Drawing.Size(153, 381);
            this.menu.TabIndex = 1;
            this.menu.Text = "menuStrip1";
            // 
            // mnProduto
            // 
            this.mnProduto.Image = ((System.Drawing.Image)(resources.GetObject("mnProduto.Image")));
            this.mnProduto.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.mnProduto.Name = "mnProduto";
            this.mnProduto.Padding = new System.Windows.Forms.Padding(4, 10, 4, 10);
            this.mnProduto.Size = new System.Drawing.Size(140, 88);
            this.mnProduto.Text = "PRODUTOS";
            this.mnProduto.Click += new System.EventHandler(this.mnProduto_Click);
            // 
            // mnCardapios
            // 
            this.mnCardapios.Image = ((System.Drawing.Image)(resources.GetObject("mnCardapios.Image")));
            this.mnCardapios.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.mnCardapios.Name = "mnCardapios";
            this.mnCardapios.Padding = new System.Windows.Forms.Padding(4, 10, 4, 10);
            this.mnCardapios.Size = new System.Drawing.Size(140, 88);
            this.mnCardapios.Text = "CARDAPIOS";
            // 
            // mnMesas
            // 
            this.mnMesas.Image = ((System.Drawing.Image)(resources.GetObject("mnMesas.Image")));
            this.mnMesas.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.mnMesas.Name = "mnMesas";
            this.mnMesas.Padding = new System.Windows.Forms.Padding(4, 10, 4, 10);
            this.mnMesas.Size = new System.Drawing.Size(140, 88);
            this.mnMesas.Text = "MESAS";
            // 
            // mnSair
            // 
            this.mnSair.Image = ((System.Drawing.Image)(resources.GetObject("mnSair.Image")));
            this.mnSair.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.mnSair.Name = "mnSair";
            this.mnSair.Padding = new System.Windows.Forms.Padding(4, 10, 4, 10);
            this.mnSair.Size = new System.Drawing.Size(140, 88);
            this.mnSair.Text = "SAIR";
            this.mnSair.Click += new System.EventHandler(this.mnSair_Click);
            // 
            // FormPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(756, 381);
            this.Controls.Add(this.menu);
            this.Font = new System.Drawing.Font("Verdana", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Black;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menu;
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.Name = "FormPrincipal";
            this.ShowIcon = false;
            this.Text = "CONTROLE DE RESTAURANTE";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menu;
        private System.Windows.Forms.ToolStripMenuItem mnProduto;
        private System.Windows.Forms.ToolStripMenuItem mnCardapios;
        private System.Windows.Forms.ToolStripMenuItem mnMesas;
        private System.Windows.Forms.ToolStripMenuItem mnSair;
    }
}