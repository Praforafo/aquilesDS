﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API_Pessoa;
using NUnit.Framework;

namespace TESTE_PESSOA
{
    [TestFixture]

    public class TestePessoa
    {
        [Test]
        public void TestarPessoaFisica()
        {
            Pessoa p = new PessoaFisica(1, "Teste", "12312312312");
            Assert.AreEqual("COD:1       NOME:Teste       CPF:11144477735", p.Imprimir());
            Assert.AreEqual(true, p.Validar());
        }

        [Test]
        public void TestarPessoaJuridica()
        {
            Pessoa p = new PessoaJuridica(1, "Teste", "12312312312");
            Assert.AreEqual("COD:1       NOME:Empresa       CNPJ:32132132132", p.Imprimir());
            Assert.AreEqual(true, p.Validar());
        }
    }
}
