﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_Pessoa
{
    public class PessoaFisica : Pessoa
    {
        public string CPF;

        public PessoaFisica(int Cod, string Nome, string CPF)
            : base(Cod, Nome)
        {
            this.CPF = CPF;
        }

        public override string Imprimir()
        {
            string dados = String.Format("COD:{0}       NOME:{1}       CPF:{2}", Cod, Nome, CPF);
            return dados;
        }

        public override bool Validar()
        {
            char[] digitos = CPF.ToCharArray();
            int peso = 10;
            int soma = 0;
            int div1, div2, resto;
            for (int i = 0; i < 9; i++)
            {
                soma += peso * Convert.ToInt16(digitos[i]);
                peso--;
            }
            resto = soma % 11;
            if (resto < 2) div1 = 0; else div1 = 11 - resto;
            if (div1 != Convert.ToInt16(digitos[9])) return false;
            peso = 11; 
            resto = 0;
            soma = 0;

            for (int i = 0; i < 10; i++)
            {
                soma += peso * Convert.ToInt16(digitos[i]);
                peso--;
            }
            resto = soma % 11;
            if (resto < 2) div2 = 0; else div2 = 11 - resto;
            if (div2 != Convert.ToInt16(digitos[10])) return false;

            return true;
        }
    }
}
