﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_Pessoa
{
    public abstract class Pessoa
    {
        public int Cod { get; set; }
        public string Nome { get; set; }
        public Pessoa(int Cod, string Nome)
        {
            this.Cod = Cod;
            this.Nome = Nome;
        }

        public abstract string Imprimir();
        public abstract bool Validar();

    }
}
