﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_Pessoa
{
    public class PessoaJuridica : Pessoa
    {
         public string CNPJ;

         public PessoaJuridica(int Cod, string Nome, string CNPJ)
            : base(Cod, Nome)
        {
            this.CNPJ = CNPJ;
        }

         public override string Imprimir()
         {
             string dados = String.Format("COD:{0}       NOME:{1}       CNPJ:{2}", Cod, Nome, CNPJ);
             return dados;
         }

         public override bool Validar()
         {
             return true;
         }
    }
}
