﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Calculadora_API;
using NUnit.Framework;

namespace TesteCalculadora
{
    public class TesteAPIcalculadora
    {
        [TestFixture]
        public class TesteAPIcalculadora
        {
            [TestCase(8, 7, 15)]
            [TestCase(7, 7, 23)]
            [TestCase(3, 2, 6)]
            public void TesteSomar(double a, double b, double c)
            {
                CalculadoraAPI obj = new CalculadoraAPI();
                Assert.AreEqual(c, obj.Somar(a, b));
            }

            [TestCase(8, 8, 0)]
            [TestCase(20, 45, 25)]
            public void TesteSubtrair(double a, double b, double c)
            {
                CalculadoraAPI obj = new CalculadoraAPI();
                Assert.AreEqual(c, obj.Subtrair(a, b));
            }

            [TestCase(3, 6, 18)]
            [TestCase(-3, -3, 9)]
            public void TestarMultiplicar(double a, double b, double c)
            {
                CalculadoraAPI obj = new CalculadoraAPI();
                Assert.AreEqual(c, obj.Multiplicar(a, b));
            }

            [TestCase(20, 5, 4)]
            [TestCase(48, 8, 6)]
            public void TestarDivisao(double a, double b, double c)
            {
                CalculadoraAPI obj = new CalculadoraAPI();
                Assert.AreEqual(c, obj.Dividir(a, b));
            }
        }
    }
}
