﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API_Carro;

namespace TESTE_CARRO
{
    class Program
    {
        static ICarro carro;
        static ICarroTurbo carro2;

        static void Main(string[] args)
        {
            carro = new Carro();
            carro2 = new CarroTurbo();
            carro.Ligar();
            carro.Acelerar();

            carro2.Ligar();
            carro2.Acelerar();
            carro2.Turbo();
            Console.ReadKey();
        }
    }
}
