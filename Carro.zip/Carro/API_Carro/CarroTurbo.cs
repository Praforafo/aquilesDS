﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_Carro
{
    public class CarroTurbo :ICarroTurbo
    {
        public void Tipo()
        {
            Console.WriteLine("Carro Turbo");
        }
        public void Ligar()
        {
            Console.WriteLine("Ligando o carro...");
        }

        public void Acelerar()
        {
            Console.WriteLine("Acelerando o carro...");
        }

        public void Turbo()
        {
            Console.WriteLine("Ligando o turbo do carro...");
        }
    }
}
