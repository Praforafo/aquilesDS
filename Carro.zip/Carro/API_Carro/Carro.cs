﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API_Carro
{
    public class Carro : ICarro
    {
        public void Tipo()
        {
            Console.WriteLine("Carro Aspirado");
        }
        public void Ligar()
        {
            Console.WriteLine("Ligando o carro...");
        }

        public void Acelerar()
        {
            Console.WriteLine("Acelerando o carro...");
        }
    }
}
