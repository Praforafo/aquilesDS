﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProdutoAPI;

namespace testeProduto
{
    class Program
    {
        static void Main(string[] args)
        {
            IprodutoRepositorio produto = new ProdutoRepositorio();
            produto.cadastra();
            produto.ler();
            Console.ReadKey();
        }
    }
}
