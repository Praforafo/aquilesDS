﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using POLIGONO_API;

namespace TESTE_POLIGONO
{
    class Program
    {
        static List<Poligono> Poligonos;

        static void Main(string[] args)
        {
            Poligonos = new List<Poligono>();

            Poligonos.Add(new Triangulo(
                new List<double>() { 10, 10, 10 })
                );
            Poligonos.Add(new Triangulo(
                new List<double>() { 10, 10, 16 })
                );
            Poligonos.Add(new Triangulo(
               new List<double>() { 6, 7, 8 })
               );
            Poligonos.Add(new Retangulo(
               new List<double>() { 11, 5, 11, 5 })
               );
            Console.ForegroundColor = ConsoleColor.Cyan;

            foreach (var i in Poligonos)
            {
                Console.WriteLine("\nTipo:{0}", i.GetType());
                Console.WriteLine("Perimetro:{0}", i.Perimetro());
                Console.WriteLine("Area:{0}\n", i.Area());
            }
            Console.ReadKey();
        }
    }
}
