﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POLIGONO_API
{
    public class Pentagono : Poligono
    {
        public Pentagono(List<double> Lados)
            : base(Lados)
        {

        }

        public override double Area()
        {
            if (Lados[0] == Lados[1] && Lados[1] == Lados[2] && Lados[2] == Lados[3] && Lados[3] == Lados[4] && Lados[4] == Lados[5])
            {
                return Lados[0] * Lados[1];
            }
            else
            {
                return Lados[0] * Lados[0];
            }
        }
    }
}
