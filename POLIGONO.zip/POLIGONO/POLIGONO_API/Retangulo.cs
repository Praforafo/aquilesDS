﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace POLIGONO_API
{
    public class Retangulo:Poligono
    {
        public Retangulo(List<double> Lados) : base(Lados) 
        { 
        
        }

        public override double Area()
        {
            if (Lados[0] != Lados[1])
            {
                return Lados[0] * Lados[1];
            }
            else 
            {
                return Lados[0] * Lados[0];            
            }
        }
    }
}
