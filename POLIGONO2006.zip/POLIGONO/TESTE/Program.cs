﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using API_POLIGONO;

namespace TESTE
{
    class Program
    {
        static List<Poligono> Poligonos = new List<Poligono>();
        static void Main(string[] args)
        {
            Poligonos.Add(new Poligono(4, 3, 4));
            Poligonos.Add(new Retangulo(4, 4, 4, 4));
            foreach (Poligono item in Poligonos)
            {
                Console.WriteLine("Tipo:" + item.GetType());
                item.ImprimirLdados();
                Console.WriteLine("Perimetro: {0:N2}",
                    item.Perimetro());
                Console.WriteLine("Area: {0:N2}",
                    item.Area());
            }
            Console.ReadKey();
        }
    }
}
