﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace API_POLIGONO
{​
    public class Retangulo:Poligono
    {​
        public double L4 {​ get; set; }​
        public Retangulo(double L1, double L2,
            double L3, double L4):base(L1,L2,L3)
        {​
            this.L4 = L4;
        }​
        public override double Perimetro()
        {​
            return base.Perimetro() + L4;
        }​
        public override double Area()
        {​
            return L1 * L2;
        }
        public override void ImprimirLdados()
        {
            base.ImprimirLdados();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Lado4: {0}", L4);
            Console.ForegroundColor = ConsoleColor.White;
        }
    }​
}​