﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using prjControleRestaurante.modelo;

namespace prjControleRestaurante.controle
{
    class ProdutoDB
    {
        string con = Conexao.Open("localhost", "restaurantedb", "root", "minas");
        public Object Listar()
        {   
            using (var banco = new restaurantedbEntidades())
            {
                //LINQ - linguagem de consulta
                banco.Database.Connection.ConnectionString = con;
                var consulta = from linhas in banco.produto.Include("tipo") //LOAD LAZZING
                               select linhas;
                return consulta.ToList();
            }
        }

        public void Inserir(produto registro)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                banco.produto.Add(registro);
                banco.SaveChanges();
            }
        }

        public void Excluir(produto registro)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;

                produto p = banco.produto.FirstOrDefault(i => i.idproduto == registro.idproduto);
                banco.Entry(p).CurrentValues.SetValues(registro);

                banco.produto.Remove(p);
                banco.SaveChanges();
            }
        }

        public void Editar(produto registro)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                produto old = banco.produto.FirstOrDefault(i => i.idproduto == registro.idproduto);
                banco.Entry(old).CurrentValues.SetValues(registro);
                banco.SaveChanges();
            }
        }

        public produto Pesquisar(int idproduto)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                modelo.produto produto = (from linha in banco.produto.Include("tipo")
                                          where linha.idproduto == idproduto
                                          select linha).First();
                return produto;
            }
        }

        internal int ProximoCodigo()
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                int cod = 0;
                try
                {
                    cod = banco.produto.Max(i => i.idproduto);
                    return cod + 1;
                }
                catch (Exception)
                {
                    cod = 1;
                }
                return cod;
            }
        }

        internal bool verificarexclusao(tipo Registro)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                modelo.produto p = banco.produto.FirstOrDefault(i => i.idtipo == Registro.idtipo);
                if (p == null) return true;
                else return false;
            }
        }

        internal object Consulta(string p)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                var query = from linhas in banco.produto
                            where linhas.nome.StartsWith(p)
                            select new
                            {
                                linhas.idproduto,
                                linhas.nome
                            };
                return query.ToList();
            }
        }

        public System.Data.DataSet Relatorio()
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                var query = from linhas in banco.produto.Include("tipo")
                            orderby linhas.nome
                            select new
                            {
                                linhas.idproduto,
                                linhas.nome,
                                linhas.preco,
                                tipo = linhas.tipo.descricao
                            };
                System.Data.DataSet DS = new System.Data.DataSet();
                DS.Tables.Add(new System.Data.DataTable("produto"));

                DS.Tables["produto"].Columns.Add("idproduto");
                DS.Tables["produto"].Columns.Add("nome");
                DS.Tables["produto"].Columns.Add("preco");
                DS.Tables["produto"].Columns.Add("tipo");

                foreach (var item in query)
                {
                    System.Data.DataRow row = DS.Tables["produto"].NewRow();
                    row["idproduto"] = item.idproduto;
                    row["nome"] = item.nome;
                    row["preco"] = String.Format("{0:C2}", item.preco);
                    row["tipo"] = item.tipo;
                    DS.Tables["produto"].Rows.Add(row);
                }
                DS.DataSetName = "dsProduto";
                return DS;
            }
        }

      public System.Data.DataSet Grafico()
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                var query = from linhas in banco.produto.Include("tipo")
                            select new
                            {
                                linhas.idproduto,
                                linhas.idtipo,
                                tipo = linhas.tipo.descricao
                            };
                System.Data.DataSet DS = new System.Data.DataSet();
                DS.Tables.Add(new System.Data.DataTable("produto"));
                DS.Tables["produto"].Columns.Add("idproduto");
                DS.Tables["produto"].Columns.Add("idtipo");
                DS.Tables["produto"].Columns.Add("tipo");
                foreach (var item in query)
                {
                    System.Data.DataRow row = DS.Tables["produto"].NewRow();
                    row["idproduto"] = item.idproduto;
                    row["idtipo"] = item.idtipo;
                    row["tipo"] = item.tipo;
                    DS.Tables["produto"].Rows.Add(row);
                }
                DS.DataSetName = "dsProduto";
                return DS;
            }
        }
    }
}