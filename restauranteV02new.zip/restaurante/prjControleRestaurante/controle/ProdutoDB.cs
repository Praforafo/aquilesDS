﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using prjControleRestaurante.modelo;

namespace prjControleRestaurante.controle
{
    class ProdutoDB
    {
        string con = Conexao.Open("localhost", "restaurantedb", "root", "minas");
        public Object Listar()
        {   
            using (var banco = new restaurantedbEntidades())
            {
                //LINQ - linguagem de consulta
                banco.Database.Connection.ConnectionString = con;
                var consulta = from linhas in banco.produto.Include("tipo") //LOAD LAZZING
                               select linhas;
                return consulta.ToList();
            }
        }

        public void Inserir(produto registro)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                banco.produto.Add(registro);
                banco.SaveChanges();
            }
        }

        public void Excluir(produto registro)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;

                produto p = banco.produto.FirstOrDefault(i => i.idproduto == registro.idproduto);
                banco.Entry(p).CurrentValues.SetValues(registro);

                banco.produto.Remove(p);
                banco.SaveChanges();
            }
        }

        public void Editar(produto registro)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                produto old = banco.produto.FirstOrDefault(i => i.idproduto == registro.idproduto);
                banco.Entry(old).CurrentValues.SetValues(registro);
                banco.SaveChanges();
            }
        }

        public produto Pesquisar(int idproduto)
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                produto produto = banco.produto.FirstOrDefault(i => i.idproduto == idproduto);
                return produto;
            }
        }

        internal int ProximoCodigo()
        {
            using (var banco = new restaurantedbEntidades())
            {
                banco.Database.Connection.ConnectionString = con;
                int cod = 0;
                try
                {
                    cod = banco.produto.Max(i => i.idproduto);
                    return cod + 1;
                }
                catch (Exception)
                {
                    cod = 1;
                }
                return cod;
            }
        }
    }
}