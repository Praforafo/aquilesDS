﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prjControleRestaurante.visao
{
    public partial class FormFichaTipo : Form
    {
        public FormFichaTipo()
        {
            InitializeComponent();
        }

        internal modelo.tipo Registro { get; set }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Registro = null;
            this.Dispose();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (Registro == null) novo();
            else editar();
            this.Dispose();
        }

        private void editar()
        {
 	        controle.Tipo tabela = new controle.Tipo();
            Registro.descricao = txtDescricao.Text;
            tabela.editar(Registro);
        }

        private void novo()
        {
 	        controle.Tipo tabela = new controle.Tipo();

            Registro = new modelo.tipo
            {
               idtipo = tabela.proximoCodigo(),
                descricao = txtDescricao.Text
            };
        }

        private void FormFichaTipo_Load(object sender, EventArgs e)
        {
            if (Registro != null)
            {
                this.Text = "Ficha tipoo Numero" + Registro.idtipo;
                txtDescricao.Text = Registro.descricao;
            }
        }
    }
}
